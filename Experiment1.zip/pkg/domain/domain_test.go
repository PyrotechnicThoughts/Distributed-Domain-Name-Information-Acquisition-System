package domain

import (
	"encoding/json"
	"fmt"
	"testing"
)

func TestDomain(t *testing.T) {
	domainInfo, err := GetDomainInfo("baidu.com")
	if err != nil {
		t.Errorf("TestDomain(): %v", err)
	}

	jsonInfo, _ := json.MarshalIndent(domainInfo, "", "    ")

	fmt.Println(string(jsonInfo))

	// res := IsDomainValid("google.com")
	// jsonInfo, _ := json.MarshalIndent(res, "", "    ")

	// fmt.Println(string(jsonInfo))
}
