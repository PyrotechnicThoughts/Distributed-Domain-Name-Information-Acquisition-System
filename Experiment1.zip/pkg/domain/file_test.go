package domain

import (
	"distributed/pkg/database"
	"distributed/pkg/util"
	"fmt"
	"testing"
)

func TestFile(t *testing.T) {
	err := InitCollection("domain")
	if err != nil {
		t.Errorf("Error: %v", err)
	}
}

func InitCollection(collection_name string) error {
	//client := database.GetClient()
	client := database.GetClient()

	_ = database.DropCollection(client, "domain", "domain")
	_ = database.DropCollection(client, util.AppConfig.MongoConfig.Database, util.AppConfig.MongoConfig.Collection)

	collection := database.GetCollection(client, util.AppConfig.MongoConfig.Database, util.AppConfig.MongoConfig.Collection)

	err := ReadFromFile(util.AppConfig.FileConfig.DomainFile, collection)
	if err != nil {
		return fmt.Errorf("Failed to init database: %v", err)
	}

	return nil
}
