package domain

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"strings"
	"sync"

	"go.mongodb.org/mongo-driver/mongo"
)

// ReadFromFile 从文件中读取域名并写入数据库
func ReadFromFile(file_name string, collection *mongo.Collection) error {
	// 打开文件
	file, err := os.Open(file_name)
	if err != nil {
		return fmt.Errorf("Failed to open file: %v", err)
	}
	defer file.Close()

	// 创建一个通道用于接收任务
	tasks := make(chan string, 10000)

	// 创建一个等待组
	var wg sync.WaitGroup

	// 启动一组worker
	const numWorkers = 100
	for i := 0; i < numWorkers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()

			for domainName := range tasks {
				domain := Domain{
					DomainName:  domainName,
					ARecords:    []string{},
					AAAARecords: []string{},
				}
				// 插入数据库
				_, err = collection.InsertOne(context.Background(), domain)
				if err != nil {
					fmt.Printf("Failed to insert domain into database: %v\n", err)
				}
			}

		}()
	}

	// 创建一个Scanner来逐行读取文件内容
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		domainName := strings.TrimSpace(scanner.Text())

		tasks <- domainName
	}

	close(tasks)

	wg.Wait()

	if err = scanner.Err(); err != nil {
		return fmt.Errorf("Error reading file: %v", err)
	}

	return nil
}
