package domain

import (
	"crypto/tls"
	"fmt"
	"github.com/likexian/whois"
	"log"
	"net"
	"net/http"
	"strings"
	"time"
)

type CertInfo struct {
	Issuer        string    `bson:"issuer"`      // 颁发者
	Subject       string    `bson:"subject"`     // 主体
	ExpiryDate    time.Time `bson:"expiry_date"` // 证书过期日期
	SignatureAlgo string    `bson:"sig_algo"`    // 签名算法
	PublicKeyAlgo string    `bson:"pubkey_algo"` // 公钥算法
}

type WhoisInfo struct {
	Registrar       string `bson:"registrar"`        // 注册商，公司或者组织
	RegistrantName  string `bson:"registrant_name"`  // 注册人姓名，个人或实体名称
	RegistrantEmail string `bson:"registrant_email"` // 注册人邮箱
	RegistrantPhone string `bson:"registrant_phone"` // 注册人电话
	RegistrantOrg   string `bson:"registrant_org"`   // 注册人公司或组织
}

// Domain 作为mongoDB中集合的结构
type Domain struct {
	DomainName  string    `bson:"domain_name"`
	ARecords    []string  `bson:"A_records"`
	AAAARecords []string  `bson:"AAAA_records"`
	CertInfo    CertInfo  `bson:"cert_info"`
	WhoisInfo   WhoisInfo `bson:"whois_info"`
	Tag         Tag       `bson:"tag"`
}

type Tag struct {
	Validation bool `bson:"validation"`
	Info       bool `bson:"info"`
}

type DomainValidationResult struct {
	Success          bool
	StatusCode       int
	RedirectLocation string
}

// 获取域名的所有信息并整合成 Domain 结构体
func GetDomainInfo(domain string) (Domain, error) {
	// 获取A记录
	aRecords, err := GetARecords(domain)
	if err != nil {
		return Domain{}, fmt.Errorf("Failed to get A records: %v", err)
	}

	// 获取AAAA记录
	aaaaRecords, err := GetAAAARecords(domain)
	if err != nil {
		return Domain{}, fmt.Errorf("Failed to get AAAA records: %v", err)
	}

	// 获取Whois信息
	whoisInfoString, err := GetWhoisInfo(domain)
	if err != nil {
		return Domain{}, fmt.Errorf("Failed to get Whois info: %v", err)
	}
	//fmt.Println(whoisInfoString)
	whoisInfo := ParseWhoisInfo(whoisInfoString)

	// 获取SSL证书信息
	certInfo, err := GetCertInfo(domain)
	if err != nil {
		return Domain{}, fmt.Errorf("Failed to get SSL cert info: %v", err)
	}

	// 组合成 Domain 结构体
	domainInfo := Domain{
		DomainName:  domain,
		ARecords:    aRecords,
		AAAARecords: aaaaRecords,
		CertInfo:    certInfo,
		WhoisInfo:   whoisInfo,
	}

	return domainInfo, nil
}

func GetARecords(domain string) ([]string, error) {
	addresses, err := net.LookupHost(domain)
	if err != nil {
		return nil, err
	}

	return addresses, nil
}

func GetAAAARecords(domain string) ([]string, error) {
	ips, err := net.LookupIP(domain)
	if err != nil {
		return nil, err
	}

	var ipv6Addresses []string
	for _, ip := range ips {
		if ip.To4() == nil {
			ipv6Addresses = append(ipv6Addresses, ip.String())
		}
	}

	return ipv6Addresses, nil
}

// 获取域名的Whois信息
func GetWhoisInfo(domain string) (string, error) {
	// 获取Whois信息
	whoisInfo, err := whois.Whois(domain)
	if err != nil {
		return "", fmt.Errorf("Failed to get Whois info: %v", err)
	}

	return whoisInfo, nil
}

// 解析Whois信息并填充WhoisInfo结构体
func ParseWhoisInfo(whoisInfo string) WhoisInfo {
	var info WhoisInfo
	lines := strings.Split(whoisInfo, "\n")
	for _, line := range lines {
		if strings.HasPrefix(line, "Registrar:") {
			info.Registrar = strings.TrimSpace(strings.TrimPrefix(line, "Registrar:"))
		} else if strings.HasPrefix(line, "Registrant Name:") {
			info.RegistrantName = strings.TrimSpace(strings.TrimPrefix(line, "Registrant Name:"))
		} else if strings.HasPrefix(line, "Registrant Email:") {
			info.RegistrantEmail = strings.TrimSpace(strings.TrimPrefix(line, "Registrant Email:"))
		} else if strings.HasPrefix(line, "Registrant Phone:") {
			info.RegistrantPhone = strings.TrimSpace(strings.TrimPrefix(line, "Registrant Phone:"))
		} else if strings.HasPrefix(line, "Registrant Organization:") {
			info.RegistrantOrg = strings.TrimSpace(strings.TrimPrefix(line, "Registrant Organization:"))
		}
	}
	return info
}

// 获取域名的SSL证书信息
func GetCertInfo(domain string) (CertInfo, error) {
	// 连接到域名并获取证书
	conn, err := tls.Dial("tcp", domain+":443", &tls.Config{
		InsecureSkipVerify: true, // 跳过证书验证
	})
	if err != nil {
		return CertInfo{}, fmt.Errorf("Failed to connect to %s: %v", domain, err)
	}
	defer conn.Close()

	// 获取远程证书链
	certificates := conn.ConnectionState().PeerCertificates
	if len(certificates) == 0 {
		return CertInfo{}, fmt.Errorf("No certificates found for %s", domain)
	}

	// 解析第一个证书
	cert := certificates[0]
	certInfo := CertInfo{
		Issuer:        cert.Issuer.CommonName,
		Subject:       cert.Subject.CommonName,
		ExpiryDate:    cert.NotAfter,
		SignatureAlgo: cert.SignatureAlgorithm.String(),
		PublicKeyAlgo: cert.PublicKeyAlgorithm.String(),
	}
	return certInfo, nil
}

func IsDomainValid(domain string) DomainValidationResult {
	// 创建一个自定义的Transport，设置超时时间
	tr := &http.Transport{
		DialContext: (&net.Dialer{
			Timeout:   3 * time.Second, // 设置连接超时时间
			KeepAlive: 3 * time.Second, // 持续连接的时间
		}).DialContext,
		TLSHandshakeTimeout:   3 * time.Second, // 设置TLS握手超时时间
		ResponseHeaderTimeout: 3 * time.Second, // 设置响应头部读取超时时间
		ExpectContinueTimeout: 1 * time.Second,
	}
	client := &http.Client{
		Transport: tr,
	}

	// 尝试HTTP
	resp, err := client.Head("http://" + domain)
	if err != nil {
		// 尝试HTTPS
		resp, err = client.Head("https://" + domain)
		if err != nil {
			log.Printf("Error occurred in validating %s, %v", domain, err)
			return DomainValidationResult{
				StatusCode: -1,
				Success:    false,
			}
		}
	}
	defer resp.Body.Close()

	// 检查重定向
	if resp.StatusCode >= 300 && resp.StatusCode < 400 {
		redirectLocation := resp.Header.Get("Location")
		if redirectLocation != "" {
			// 解析重定向的域名
			return DomainValidationResult{
				Success:          true,
				StatusCode:       resp.StatusCode,
				RedirectLocation: redirectLocation,
			}
		}
	}

	if resp.StatusCode >= 200 && resp.StatusCode < 300 {
		return DomainValidationResult{
			Success:    true,
			StatusCode: resp.StatusCode,
		}
	} else {
		return DomainValidationResult{
			Success:    false,
			StatusCode: resp.StatusCode,
		}
	}
}
