package crud

import (
	"context"
	"distributed/pkg/database"
	"distributed/pkg/domain"
	"distributed/pkg/util"
	"errors"
	"fmt"
	"log"
	"net/url"
	"strconv"
	"strings"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

func UpdateToMongoDB(domainInfo domain.Domain) {
	filter := bson.M{
		"domain_name": domainInfo.DomainName,
	}

	// 定义要更新的字段
	update := bson.M{}

	if domainInfo.CertInfo != (domain.CertInfo{}) && domainInfo.WhoisInfo != (domain.WhoisInfo{}) {
		update["$set"] = bson.M{"cert_info": domainInfo.CertInfo, "whois_info": domainInfo.WhoisInfo}
	} else if domainInfo.CertInfo != (domain.CertInfo{}) {
		update["$set"] = bson.M{"cert_info": domainInfo.CertInfo}
	} else {
		update["$set"] = bson.M{"whois_info": domainInfo.WhoisInfo}
	}
	if len(domainInfo.AAAARecords) > 0 && len(domainInfo.ARecords) > 0 {
		update["$addToSet"] = bson.M{"A_records": bson.M{"$each": domainInfo.ARecords}, "AAAA_records": bson.M{"$each": domainInfo.AAAARecords}}
	} else if len(domainInfo.ARecords) > 0 {
		update["$addToSet"] = bson.M{"A_records": bson.M{"$each": domainInfo.ARecords}}
	} else {
		update["$addToSet"] = bson.M{"AAAA_records": bson.M{"$each": domainInfo.AAAARecords}}
	}

	mongoClient := database.GetClient()
	config := util.AppConfig.MongoConfig

	// 执行更新操作
	result, err := mongoClient.Database(config.Database).Collection(config.Collection).UpdateOne(context.Background(), filter, update)
	if err != nil {
		log.Fatalf("Failed to update document: %v", err)
	}

	log.Printf("Updated %d document\n", result.ModifiedCount)
}

func UpdateValidation(result string, collection *mongo.Collection) error {
	// 解析验证结果
	parts := strings.Split(result, ", ")
	if len(parts) != 4 {
		return errors.New("invalid validation result format")
	}

	domainName := strings.TrimPrefix(parts[0], "Domain: ")
	successStr := strings.TrimPrefix(parts[1], "Success: ")
	// statusCodeStr := strings.TrimPrefix(parts[2], "StatusCode: ")
	redirectLocation := strings.TrimPrefix(parts[3], "RedirectLocation: ")

	success, err := strconv.ParseBool(successStr)
	if err != nil {
		return fmt.Errorf("failed to parse success value: %v", err)
	}
	/*
	   statusCode, err := strconv.Atoi(statusCodeStr)
	   if err != nil {
	       return fmt.Errorf("failed to parse status code value: %v", err)
	   }
	*/

	// 根据 success 来更新记录
	if success {
		// 如果成功并且有重定向地址，则更新重定向地址
		if redirectLocation != "" {
			newDomain := ExtractRedirectDomain(redirectLocation)
			if newDomain != "" {
				// 根据 domainName 在数据库中查找记录并替换 domain_name 字段
				_, err := collection.UpdateOne(context.Background(), bson.M{"domain_name": domainName}, bson.M{"$set": bson.M{"domain_name": newDomain}})
				if err != nil {
					return fmt.Errorf("更新 MongoDB 中的记录失败：%v", err)
				}

				log.Printf("Update %s to %s\n", domainName, newDomain)
			}
		}
	} else {
		// 如果失败，则删除记录
		_, err := collection.DeleteOne(context.Background(), bson.M{"domain_name": domainName})
		if err != nil {
			return fmt.Errorf("failed to delete document from MongoDB: %v", err)
		}

		log.Printf("Delete %s\n", domainName)
	}

	return nil
}

// extractRedirectDomain 从重定向地址中提取域名
func ExtractRedirectDomain(redirectLocation string) string {
	u, err := url.Parse(redirectLocation)
	if err != nil {
		log.Printf("Failed to parse redirect location: %v", err)
		return ""
	}

	// 提取域名
	host := strings.ToLower(u.Hostname())
	return host
}
