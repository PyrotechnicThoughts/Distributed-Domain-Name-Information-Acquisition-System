package crud

import (
	//	"distributed/pkg/domain"
	//	"encoding/json"
	"fmt"
	"testing"
)

func TestCrud(t *testing.T) {
	//	domainInfo, err := domain.GetDomainInfo("baidu.com")
	//	if err != nil {
	//		t.Errorf("TestCrud(): %v", err)
	//	}

	//	UpdateToMongoDB(domainInfo)

	//	jsonInfo, _ := json.MarshalIndent(domainInfo, "", "    ")
	//	fmt.Println(string(jsonInfo))

	fmt.Println(ExtractRedirectDomain("http://www.baidu.com"))
}
