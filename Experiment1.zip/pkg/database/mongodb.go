package database

import (
	"context"
	"distributed/pkg/util"
	"fmt"
	"log"
	"sync"

	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var (
	mongoClient        *mongo.Client
	mongoClientInitErr error
	mongoClientOnce    sync.Once
	mongoClientMutex   sync.Mutex
)

func initMongoClient() {
	config := util.AppConfig.MongoConfig

	// 构建 MongoDB 连接字符串
	uri := fmt.Sprintf("mongodb://%s:%s@%s:%d", config.Username, config.Password, config.Host, config.Port)
	log.Println("MongoDB RUI: ", uri)

	// 设置连接选项
	clientOptions := options.Client().ApplyURI(uri)

	// 连接到 MongoDB
	mongoClient, mongoClientInitErr = mongo.Connect(context.Background(), clientOptions)
	if mongoClientInitErr != nil {
		panic(fmt.Sprintf(mongoClientInitErr.Error()))
		return
	}

	// 检查连接是否成功
	err := mongoClient.Ping(context.Background(), nil)
	if err != nil {
		log.Fatal(err)
		return
	}

	log.Println("Connected to MongoDB!")
	fmt.Println("Connected to MongoDB!")
}

// GetClient 返回mongodb客户端
func GetClient() *mongo.Client {
	// 使用 sync.Once 确保只初始化一次
	mongoClientOnce.Do(func() {
		initMongoClient()
	})

	// 获取客户端前加锁
	mongoClientMutex.Lock()
	defer mongoClientMutex.Unlock()

	return mongoClient
}

// GetCollection 获取 MongoDB 集合
func GetCollection(client *mongo.Client, databaseName, collectionName string) *mongo.Collection {
	return client.Database(databaseName).Collection(collectionName)
}

// DropCollection 删除指定数据库中的指定集合
func DropCollection(client *mongo.Client, databaseName, collectionName string) error {
	// 获取集合
	collection := client.Database(databaseName).Collection(collectionName)

	// 删除集合
	err := collection.Drop(context.Background())
	if err != nil {
		return fmt.Errorf("failed to drop collection: %v", err)
	}

	log.Printf("Collection %s in database %s dropped successfully\n", collectionName, databaseName)
	fmt.Printf("Collection %s in database %s dropped successfully\n", collectionName, databaseName)
	return nil
}

// CloseMongoClient 关闭 MongoDB 客户端连接
func CloseMongoClient() {
	if mongoClient != nil {
		err := mongoClient.Disconnect(context.Background())
		if err != nil {
			log.Printf("Error disconnecting from MongoDB: %v", err)
		}
		log.Println("MongoDB client disconnected")
		fmt.Println("MongoDB client disconnected")
	}
}
