package database

import (
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"testing"
)

func TestMongoDB(t *testing.T) {
	// 创建 MongoDB 客户端连接
	//	client := GetClient()
	client := MongoDBClient
	if client == nil {
		t.Fatalf("TestMongoDB(): Failed to connect to MongoDB.")
	}
	defer client.Disconnect(context.Background())

	// 创建测试数据
	testData := []interface{}{
		bson.M{"name": "Alice", "age": 30},
		bson.M{"name": "Bob", "age": 25},
	}

	_ = DropCollection(client, "test", "test_collection")

	// 获取测试集合
	collection := GetCollection(client, "test", "test_collection")

	// 插入测试数据
	_, err := collection.InsertMany(context.Background(), testData)
	if err != nil {
		t.Fatalf("Failed to insert test data: %v", err)
	}

	// 查询测试数据
	var results []bson.M
	cursor, err := collection.Find(context.Background(), bson.M{})
	if err != nil {
		t.Fatalf("Failed to find test data: %v", err)
	}
	defer cursor.Close(context.Background())
	if err := cursor.All(context.Background(), &results); err != nil {
		t.Fatalf("Failed to decode test data: %v", err)
	}

	// 断言测试结果
	if len(results) != 2 {
		t.Errorf("Expected 2 documents, got %d", len(results))
	}
}
