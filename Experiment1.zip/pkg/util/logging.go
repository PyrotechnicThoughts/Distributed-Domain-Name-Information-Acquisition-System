package util

import (
	//	"io"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"sync"
	"time"
)

const (
	LogLevelInfo    = iota // 普通信息
	LogLevelWarning        // 警告
	LogLevelError          // 错误
	LogLevelFatal          // 致命错误
)

var (
	logger *Logger
	once   sync.Once
)

type Logger struct {
	mu      sync.Mutex
	logFile *os.File
}

func GetLogger() *Logger {
	once.Do(func() {
		logger = &Logger{}
		logger.initLogFile()
	})
	return logger
}

func (l *Logger) initLogFile() {
	logsDir := "../../logs"
	err := os.MkdirAll(logsDir, 0755)
	if err != nil {
		panic(err)
	}

	today := time.Now().Format("2006-01-02-15-04-05")
	logFileName := filepath.Join(logsDir, today+".log")
	fmt.Println(logFileName)

	l.logFile, err = os.OpenFile(logFileName, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		panic(err)
	}

	// log.SetOutput(io.MultiWriter(l.logFile, os.Stdout))
	log.SetOutput(l.logFile)
	log.SetFlags(log.Ldate | log.Ltime | log.Lshortfile)
}

func (l *Logger) CloseLogFile() {
	if l.logFile != nil {
		l.logFile.Close()
	}
}

func (l *Logger) Log(level int, message string) {
	switch level {
	case LogLevelInfo:
		log.Println("[INFO]", message)
	case LogLevelWarning:
		log.Println("[WARNING]", message)
	case LogLevelError:
		log.Println("[ERROR]", message)
	case LogLevelFatal:
		log.Fatalln("[FATAL]", message)
	}
}

func Info(message string) {
	GetLogger().Log(LogLevelInfo, message)
}

func Warning(message string) {
	GetLogger().Log(LogLevelWarning, message)
}

func Error(message string) {
	GetLogger().Log(LogLevelError, message)
}

func Fatal(message string) {
	GetLogger().Log(LogLevelFatal, message)
}
