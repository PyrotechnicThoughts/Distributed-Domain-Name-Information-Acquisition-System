package util

import (
	"encoding/json"
	"fmt"
	"testing"
)

func TestConfig(t *testing.T) {
	jsonInfo, _ := json.MarshalIndent(AppConfig, "", "    ")
	// fmt.Printf("Config: %v\n", AppConfig)
	fmt.Println(string(jsonInfo))
}
