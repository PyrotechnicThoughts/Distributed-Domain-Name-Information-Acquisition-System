package util

import (
	"fmt"
	"github.com/spf13/viper"
)

var AppConfig Config

type Config struct {
	MongoConfig MongoConfig `mapstructure:"mongo"`
	FileConfig  FileConfig  `mapstructure:"file"`
	KafkaConfig KafkaConfig `mapstructure:"kafka"`
	TaskConfig  TaskConfig  `mapstructure:"task"`
}

type TaskConfig struct {
	Task1 Task `mapstructure:"task1"`
	Task2 Task `mapstructure:"task2"`
}

type Task struct {
	Batchsize1 int    `mapstructure:"batchsize1"`
	Topic1     string `mapstructure:"topic1"`
	Partition1 int    `mapstructure:"partition1"`
	Topic2     string `mapstructure:"topic2"`
	Production string `mapstructure:"production"`
}

type MongoConfig struct {
	Host       string `mapstructure:"host"`
	Port       int    `mapstructure:"port"`
	Username   string `mapstructure:"username"`
	Password   string `mapstructure:"password"`
	Database   string `mapstructure:"database"`
	Collection string `mapstructure:"collection"`
}

type KafkaConfig struct {
	Broker KafkaBrokerConfig  `mapstructure:"broker"`
	Topics []KafkaTopicConfig `mapstructure:"topics"`
}

type KafkaBrokerConfig struct {
	Host string `mapstructure:"host"`
	Port int    `mapstructure:"port"`
}

type KafkaTopicConfig struct {
	Name       string `mapstructure:"name"`
	Partitions int    `mapstructure:"partitions"`
}

type FileConfig struct {
	DomainFile string `mapstructure:"domainfile"`
}

func init() {
	if err := LoadConfig("../../configs/config.yaml"); err != nil {
		panic(fmt.Errorf("Failed to load config: %s", err))
	}
}

// 从文件中读取
func LoadConfig(configFile string) error {
	viper.SetConfigFile(configFile)

	if err := viper.ReadInConfig(); err != nil {
		return fmt.Errorf("Failed to read config file: %s", err)
	}

	if err := viper.Unmarshal(&AppConfig); err != nil {
		return fmt.Errorf("Failed to unmarshal config: %s", err)
	}

	return nil
}
