#!/bin/bash -v

# 设置交叉编译环境变量
export GOOS=windows
export GOARCH=amd64  # 或者使用386，取决于你的目标平台

# 编译Go程序为Windows可执行文件
#go build -o cmd/init/main.exe cmd/init/main.go
#go build -o cmd/kafka/main.exe cmd/kafka/main.go
go build -o cmd/task1/main.exe cmd/task1/main.go
go build -o cmd/task2/main.exe cmd/task2/main.go

# 清理环境变量
unset GOOS
unset GOARCH
