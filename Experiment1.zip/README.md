
## Architecture

project/
├── cmd/
│   ├── master/
│   │   └── main.go            # Master 节点程序入口文件
│   └── worker/
│       └── main.go            # Worker 节点程序入口文件
├── internal/
│   ├── master/
│   │   ├── handler.go         # Master 节点的请求处理逻辑
│   │   ├── scheduler.go       # Master 节点的任务调度逻辑
│   │   ├── server.go          # Master 节点的 gRPC 服务
│   │   └── service.go         # Master 节点的服务逻辑
│   └── worker/
│       ├── handler.go         # Worker 节点的请求处理逻辑
│       ├── server.go          # Worker 节点的 gRPC 服务
│       └── service.go         # Worker 节点的服务逻辑
├── pkg/
│   ├── api/                   # gRPC 接口定义
│   │   ├── master.pb.go
│   │   ├── master.proto
│   │   ├── worker.pb.go
│   │   └── worker.proto
│   └── util/                  # 工具函数
│       ├── logging.go         # 日志工具函数
│       └── mongodb.go         # MongoDB 数据库操作
├── configs/                   # 配置文件
│   ├── master.yaml
│   ├── worker.yaml
│   └── mongodb.yaml           # MongoDB 配置文件
├── scripts/                   # 脚本文件
│   └── deploy.sh              # 部署脚本
├── testdata/                  # 测试数据
├── README.md                  # 项目说明文档
└── go.mod

## 前置

- mongoDB的增删改查
- 容器中的mongoDB如何存储数据不丢失
- 


## 项目kafka架构

- kafka cluster
    - broker 
        - topic:域名待验证
            - producer: x1
            - consumer: <=3
            - partition: x3
        - topic:合法性待更新
            - producer: x3
            - consumer: x1
            - partition: x1
        - topic:域名信息待获取
        - topic:域名信息待更新




https://blog.csdn.net/mmgithub123/article/details/124507842