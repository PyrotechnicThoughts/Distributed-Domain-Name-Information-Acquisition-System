#!/bin/bash -v

go build -o cmd/init/main cmd/init/main.go
go build -o cmd/kafka/main cmd/kafka/main.go
go build -o cmd/task1/main cmd/task1/main.go
go build -o cmd/task2/main cmd/task2/main.go
