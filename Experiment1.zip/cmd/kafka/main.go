package main

import (
	"bufio"
	"distributed/internal/kafka"
	"distributed/pkg/util"
	"fmt"
	"log"
	"os"
	"strings"
)

func main() {
	defer util.GetLogger().CloseLogFile()

	log.Println("")

	reader := bufio.NewReader(os.Stdin)

	fmt.Println("Type 'help' to see available commands.")

	for {
		fmt.Print(">> ")
		input, err := reader.ReadString('\n')
		if err != nil {
			fmt.Println("Error reading input:", err)
			log.Println("Error reading input:", err)
			continue
		}

		// 移除输入中的换行符
		input = strings.TrimSpace(input)

		// 解析用户输入的命令
		switch input {
		case "help":
			showHelp()
		case "h":
			showHelp()
		case "configB":
			fmt.Println("Begin configuring Kafka broker...")
			log.Println("Begin configuring Kafka broker...")
			kafka.ConfigBroker()
			fmt.Println("Finish configuring Kafka broker.")
			log.Println("Finish configuring Kafka broker.")
		case "deleteCO":
			kafka.DeleteCOnsumerOffset()
		case "deleteT":
			kafka.DeleteAllTopic()
		case "v":
			kafka.GetKafkaInfo("")
		case "d":
			kafka.GetKafkaInfo("detail")
		case "exit":
			fmt.Println("Exiting...")
			log.Println("Exiting...")
			return
		case "e":
			fmt.Println("Exiting...")
			log.Println("Exiting...")
			return
		case "E":
			fmt.Println("Exiting...")
			log.Println("Exiting...")
			return
		default:
			fmt.Println("Invalid command. Type 'help' to see available commands.")
			log.Println("Invalid command. Type 'help' to see available commands.")
		}
	}
}

func showHelp() {
	fmt.Println("Available commands:")
	fmt.Println("  [h]elp             Show available commands")
	fmt.Println("  [configB]          Configure Kafka broker")
	fmt.Println("  [deleteCO]         Delete Consumer Offset")
	fmt.Println("  [deleteT]          Delete all topics")
	fmt.Println("  [v]iewKafkaInfo    View information of System")
	fmt.Println("  [d]viewKafkaDeatil View Kafka logs")
	fmt.Println("  [e|E]xit           Exit the program")
}
