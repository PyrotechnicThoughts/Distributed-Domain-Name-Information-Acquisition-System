package main

import (
	"distributed/pkg/util"
	"flag"
	"fmt"
	"log"
	"os"

	"distributed/internal/kafka"
	"distributed/pkg/database"
)

func main() {
	defer util.GetLogger().CloseLogFile()
	defer database.CloseMongoClient()

	log.Println("")

	// 定义命令行参数
	action := flag.String("action", "", "Action to perform: producer, validator, updater")
	flag.Parse()

	// 检查命令行参数是否为空
	if *action == "" {
		fmt.Println("Error: Please provide an action to perform.")
		log.Println("Error: Please provide an action to perform.")
		flag.PrintDefaults()
		os.Exit(1)
	}

	// 根据命令行参数执行相应动作
	switch *action {
	case "producer":
		log.Println("Start producer...")
		fmt.Println("Start producer...")
		kafka.ProduceDomains("task1")
		log.Println("End producer...")
		fmt.Println("End producer...")
	case "validator":
		log.Println("Start validator...")
		fmt.Println("Start validator...")
		kafka.ValidateDomains()
		log.Println("End validator...")
		fmt.Println("End validator...")
	case "updater":
		log.Println("Start updater...")
		fmt.Println("Start updater...")
		kafka.UpdateValidationResults()
		log.Println("End updater...")
		fmt.Println("End updater...")
	default:
		fmt.Println("Error: Invalid action provided.")
		log.Println("Error: Invalid action provided.")
		flag.PrintDefaults()
		os.Exit(1)
	}
}
