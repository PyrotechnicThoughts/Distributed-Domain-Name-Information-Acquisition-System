package main

import (
	"distributed/pkg/util"
	"flag"
	"fmt"
	"log"
	"os"

	"distributed/internal/kafka"
	"distributed/pkg/database"
)

func main() {
	defer util.GetLogger().CloseLogFile()
	defer database.CloseMongoClient()

	log.Println("")

	// 定义命令行参数
	action := flag.String("action", "", "Action to perform: producer, getter, updater")
	flag.Parse()

	// 检查命令行参数是否为空
	if *action == "" {
		fmt.Println("Error: Please provide an action to perform.")
		log.Println("Error: Please provide an action to perform.")
		flag.PrintDefaults()
		os.Exit(1)
	}

	// 根据命令行参数执行相应动作
	switch *action {
	case "producer":
		log.Println("Start producer...")
		fmt.Println("Start producer...")
		kafka.ProduceDomains("task2")
		log.Println("End producer...")
		fmt.Println("End producer...")
	case "getter":
		log.Println("Start getter...")
		fmt.Println("Start getter...")
		kafka.GetDomainInfo()
		log.Println("End getter...")
		fmt.Println("End getter...")
	case "updater":
		log.Println("Start updater...")
		fmt.Println("Start updater...")
		kafka.UpdateDomainInfo()
		log.Println("End updater...")
		fmt.Println("End updater...")
	default:
		fmt.Println("Error: Invalid action provided.")
		log.Println("Error: Invalid action provided.")
		flag.PrintDefaults()
		os.Exit(1)
	}
}
