package main

import (
	"distributed/pkg/database"
	"distributed/pkg/domain"
	"distributed/pkg/util"
	"fmt"
	"log"
)

func main() {
	defer util.GetLogger().CloseLogFile()
	defer database.CloseMongoClient()

	log.Println("")

	log.Println("Init ...[some necessary jobs]")
	fmt.Println("Init ...[some necessary jobs]")
	err := InitCollection()
	if err != nil {
		panic(err.Error())
	}
	log.Println("Init done")
	fmt.Println("Init done")
}

func InitCollection() error {
	client := database.GetClient()

	_ = database.DropCollection(client, util.AppConfig.MongoConfig.Database, util.AppConfig.MongoConfig.Collection)

	collection := database.GetCollection(client, util.AppConfig.MongoConfig.Database, util.AppConfig.MongoConfig.Collection)

	fmt.Println("Start initing collection from file...")
	log.Println("Start initing collection from file...")
	err := domain.ReadFromFile(util.AppConfig.FileConfig.DomainFile, collection)
	if err != nil {
		return fmt.Errorf("Failed to init database: %v", err)
	}

	return nil
}
