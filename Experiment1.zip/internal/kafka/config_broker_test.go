package kafka

import (
	"testing"
)

func TestConfigBroker(t *testing.T) {
	ConfigBroker()
}
