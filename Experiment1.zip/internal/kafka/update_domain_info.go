package kafka

import (
	"context"
	"distributed/pkg/crud"
	"distributed/pkg/database"
	"distributed/pkg/domain"
	"distributed/pkg/util"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"os/signal"
	"strconv"
	"syscall"

	"github.com/IBM/sarama"
	"go.mongodb.org/mongo-driver/mongo"
)

var (
	updateInfoConsumer   sarama.ConsumerGroup
	updateInfoCollection *mongo.Collection
)

func UpdateDomainInfo() {
	config := util.AppConfig

	// mongoDB集合
	mongoClient := database.GetClient()
	updateInfoCollection = mongoClient.Database(config.MongoConfig.Database).Collection(config.MongoConfig.Collection)

	// 连接到 Kafka broker
	kafkaConfig := sarama.NewConfig()
	kafkaConfig.Version = sarama.V2_8_1_0 // 使用 Kafka 2.8.1 版本

	kafkaClient, err := sarama.NewClient([]string{config.KafkaConfig.Broker.Host + ":" + strconv.Itoa(config.KafkaConfig.Broker.Port)}, kafkaConfig)
	if err != nil {
		log.Fatal(fmt.Sprintf("Error creating Kafka client: %v", err))
	}
	defer kafkaClient.Close()

	// 创建 Kafka 消费者
	updateInfoConsumer, err = sarama.NewConsumerGroupFromClient("task2_group2", kafkaClient)
	if err != nil {
		log.Fatal(fmt.Sprintf("Error creating Kafka consumer: %v", err))
	}
	//	defer updateInfoConsumer.Close()

	// 创建一个上下文以便取消操作
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// 监听操作系统的信号，以便在接收到中断信号时优雅地关闭程序
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-sigCh
		log.Println("Received termination signal. Shutting down...")
		fmt.Println("Received termination signal. Shutting down...")
		cancel()
	}()

	consumer := UpdateInfoConsumer{
		ready: make(chan bool),
	}

	// 启动 Kafka 消费者组
	go func() {
		for {
			err := updateInfoConsumer.Consume(ctx, []string{config.TaskConfig.Task2.Topic2}, &consumer)
			if err != nil {
				log.Printf("Error from consumer: %v", err)
			}
			// 检查上下文是否被取消，如果是，则退出循环
			if ctx.Err() != nil {
				return
			}
			consumer.ready = make(chan bool)
		}
	}()

	<-consumer.ready // 等待消费者组准备好

	log.Println("Consumer group is ready, consuming messages...")
	fmt.Println("Consumer group is ready, consuming messages...")

	// 等待上下文被取消
	<-ctx.Done()
}

// Consumer 代表 Kafka 消费者组
type UpdateInfoConsumer struct {
	ready chan bool // 定义一个通道，用于表示消费者组是否准备就绪
}

// Setup 在消费者组启动时调用
func (c *UpdateInfoConsumer) Setup(sarama.ConsumerGroupSession) error {
	close(c.ready) // 关闭通道以表示消费者组已准备就绪
	return nil
}

// Cleanup 在消费者组结束时调用
func (c *UpdateInfoConsumer) Cleanup(sarama.ConsumerGroupSession) error {
	return nil
}

// ConsumeClaim 消费消息
func (c *UpdateInfoConsumer) ConsumeClaim(session sarama.ConsumerGroupSession, claim sarama.ConsumerGroupClaim) error {
	fmt.Println("ConsumeClaim invoked...")
	log.Println("ConsumeClaim invoked...")

	// 处理消息
	for message := range claim.Messages() {
		// 处理消息
		err := processDomainInfo(message, session)
		if err != nil {
			log.Printf("Error processing message: %v", err)
		}
	}

	return nil
}

// 处理验证结果并将其更新到 MongoDB 中
func processDomainInfo(message *sarama.ConsumerMessage, session sarama.ConsumerGroupSession) error {
	// 解析消息
	result := string(message.Value)
	log.Printf("Received domain info: %v", result)

	var domainInfo domain.Domain
	err := json.Unmarshal([]byte(result), &domainInfo)
	if err != nil {
		log.Fatalf("Error decoding JSON: %v", err)
		session.MarkMessage(message, "")
		return nil
	}

	// 解析结果并更新到 MongoDB 中
	crud.UpdateToMongoDB(domainInfo)

	session.MarkMessage(message, "")
	return nil
}
