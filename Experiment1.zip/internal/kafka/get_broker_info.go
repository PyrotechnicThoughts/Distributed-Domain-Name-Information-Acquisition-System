package kafka

import (
	"fmt"
	"strconv"
	//"strings"
	"distributed/pkg/util"
	"log"

	"github.com/IBM/sarama"
)

// GetKafkaMetadata 获取 Kafka 的元数据信息
func GetKafkaInfo(info string) {
	config := sarama.NewConfig()
	config.Version = sarama.V2_8_1_0

	kafka_cfg := util.AppConfig.KafkaConfig.Broker

	admin, err := sarama.NewClusterAdmin([]string{kafka_cfg.Host + ":" + strconv.Itoa(kafka_cfg.Port)}, config)
	if err != nil {
		log.Fatalf("error connecting to Kafka broker: %v", err)
	}
	defer admin.Close()

	// 获取 Broker 列表
	brokers, _, err := admin.DescribeCluster()
	if err != nil {
		log.Fatalf("error describing Kafka cluster: %v", err)
	}
	fmt.Println("Broker List:")

	for _, broker := range brokers {
		fmt.Printf("\tID: %d, Address: %s\n", broker.ID(), broker.Addr())
	}

	// 获取主题列表
	topics, err := admin.ListTopics()
	if err != nil {
		log.Fatalf("获取主题列表时出错：%v", err)
		fmt.Printf("获取主题列表时出错：%v", err)
	}

	fmt.Println("Topic List:")
	for topic := range topics {
		fmt.Printf("\t%s\n", topic)
	}

	// 获取消费组信息
	groups, err := admin.ListConsumerGroups()
	if err != nil {
		log.Fatalf("获取消费组信息时出错：%v", err)
		fmt.Printf("获取消费组信息时出错：%v", err)
	}

	fmt.Println("Consumer Group Info: ")
	for groupName := range groups {
		fmt.Printf("\t%s\n", groupName)

		// 获取消费者组的详细信息
		groupDetails, err := admin.DescribeConsumerGroups([]string{groupName})
		if err != nil {
			log.Fatalf("获取消费者组 %s 的详细信息时出错：%v", groupName, err)
		}
		for _, details := range groupDetails {
			for _, member := range details.Members {
				fmt.Printf("\t\t%s\n", member.ClientHost)
			}
		}
	}

	fmt.Println("数据积压情况: ")

	if info == "detail" {
		if _, exists := topics["get_validation_info"]; exists {
			DataBacklog("get_validation_info", "task1_group1", "127.0.0.1:9092", "detail")
		}

		if _, exists := topics["update_validation_info"]; exists {
			DataBacklog("update_validation_info", "task1_group2", "127.0.0.1:9092", "detail")
		}

		if _, exists := topics["get_domain_info"]; exists {
			DataBacklog("get_domain_info", "task2_group1", "127.0.0.1:9092", "detail")
		}

		if _, exists := topics["update_domain_info"]; exists {
			DataBacklog("update_domain_info", "task2_group2", "127.0.0.1:9092", "detail")
		}
	}else{
		if _, exists := topics["get_validation_info"]; exists {
			DataBacklog("get_validation_info", "task1_group1", "127.0.0.1:9092", "")
		}

		if _, exists := topics["update_validation_info"]; exists {
			DataBacklog("update_validation_info", "task1_group2", "127.0.0.1:9092", "")
		}

		if _, exists := topics["get_domain_info"]; exists {
			DataBacklog("get_domain_info", "task2_group1", "127.0.0.1:9092", "")
		}

		if _, exists := topics["update_domain_info"]; exists {
			DataBacklog("update_domain_info", "task2_group2", "127.0.0.1:9092", "")
		}
	}


	// if info == "detail" {
	// 	DataBacklog("get_validation_info", "task1_group1", "127.0.0.1:9092", "detail")
	// 	DataBacklog("update_validation_info", "task1_group2", "127.0.0.1:9092", "detail")
	// 	DataBacklog("get_domain_info", "task2_group1", "127.0.0.1:9092", "detail")
	// 	DataBacklog("update_domain_info", "task2_group2", "127.0.0.1:9092", "detail")
	// } else {
	// 	DataBacklog("get_validation_info", "task1_group1", "127.0.0.1:9092", "")
	// 	DataBacklog("update_validation_info", "task1_group2", "127.0.0.1:9092", "")
	// 	DataBacklog("get_domain_info", "task2_group1", "127.0.0.1:9092", "")
	// 	DataBacklog("update_domain_info", "task2_group2", "127.0.0.1:9092", "")
	// }
}

func DataBacklog(topic, groupId, broker string, info string) {
	// 获取分区数
	config := sarama.NewConfig()
	client, err := sarama.NewClient([]string{broker}, config)
	if err != nil {
		log.Fatalf(err.Error())
		return
	}
	defer client.Close()
	
	partitions, err := client.Partitions(topic)
	if err != nil {
		log.Println(err.Error())
		return
	}

	om, err := sarama.NewOffsetManagerFromClient(groupId, client)
	if err != nil {
		log.Fatalf(err.Error())
		return
	}

	var totalBacklog int64 = 0

	if info == "detail" {
		fmt.Printf("partation\t下一条消息offset\t下一次提交offset\t数据积压量\n")
	}
	for _, partition := range partitions {
		// 调用 sarama.Client的GetOffset方法。返回kafka中下一条数据的offset。
		// 如果该分区没有过数据，返回值将为0。
		offset, err := client.GetOffset(topic, partition, -1)
		if err != nil {
			log.Fatalf(err.Error())
		}

		pom, err := om.ManagePartition(topic, partition) // 创建 sarama.PartitionOffsetManager
		if err != nil {
			log.Fatalf(err.Error())
		}

		var backlog int64
		// 调用 sarama.PartitionOffsetManager的NextOffset方法。返回下一次要消费的offset
		// 如果消费者组未消费过该partation的数据，返回值将为-1
		n, string := pom.NextOffset()
		if string != "" {
			log.Fatalf(string)
		}
		if n == -1 {
			backlog = offset
		} else {
			backlog = offset - n
		}

		totalBacklog += backlog

		if info == "detail" && backlog != 0 {
			fmt.Printf("%d\t\t%d\t\t%d\t\t%d\n", partition, offset, n, backlog)
		}
	}

	fmt.Printf("%s的%s主题上，消费者组%s的数据积压量总数为%d\n", broker, topic, groupId, totalBacklog)
}
