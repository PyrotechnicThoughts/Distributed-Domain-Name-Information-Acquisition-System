package kafka

import (
	"context"
	"distributed/pkg/crud"
	"distributed/pkg/database"
	"distributed/pkg/util"
	"errors"
	"fmt"
	"log"
	"os"
	"os/signal"
	"strconv"
	"syscall"

	"github.com/IBM/sarama"
	"go.mongodb.org/mongo-driver/mongo"
)

var (
	updateValidationConsumer   sarama.ConsumerGroup
	updateValidationCollection *mongo.Collection
)

func UpdateValidationResults() {
	config := util.AppConfig

	// mongoDB集合
	mongoClient := database.GetClient()
	updateValidationCollection = mongoClient.Database(config.MongoConfig.Database).Collection(config.MongoConfig.Collection)

	// 连接到 Kafka broker
	kafkaConfig := sarama.NewConfig()
	kafkaConfig.Version = sarama.V2_8_1_0 // 使用 Kafka 2.8.1 版本

	kafkaClient, err := sarama.NewClient([]string{config.KafkaConfig.Broker.Host + ":" + strconv.Itoa(config.KafkaConfig.Broker.Port)}, kafkaConfig)
	if err != nil {
		log.Fatal(fmt.Sprintf("Error creating Kafka client: %v", err))
	}
	defer kafkaClient.Close()

	// 创建 Kafka 消费者
	updateValidationConsumer, err = sarama.NewConsumerGroupFromClient("task1_group2", kafkaClient)
	if err != nil {
		log.Fatal(fmt.Sprintf("Error creating Kafka consumer: %v", err))
	}
	//	defer updateValidationConsumer.Close()

	// 创建一个上下文以便取消操作
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// 监听操作系统的信号，以便在接收到中断信号时优雅地关闭程序
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-sigCh
		log.Println("Received termination signal. Shutting down...")
		fmt.Println("Received termination signal. Shutting down...")
		cancel()
	}()

	consumer := UpdateValidationConsumer{
		ready: make(chan bool),
	}

	// 启动 Kafka 消费者组
	go func() {
		for {
			// 检查上下文是否被取消，如果是，则退出循环
			if ctx.Err() != nil {
				log.Printf("In goroutine, ctx.Err(): %v", ctx.Err())
				return
			}

			err := updateValidationConsumer.Consume(ctx, []string{config.TaskConfig.Task1.Topic2}, &consumer)
			if err != nil {
				log.Printf("Error from consumer: %v", err)
			}

			consumer.ready = make(chan bool)
		}
	}()

	<-consumer.ready // 等待消费者组准备好

	log.Println("Consumer group is ready, consuming messages...")
	fmt.Println("Consumer group is ready, consuming messages...")

	// 等待上下文被取消
	<-ctx.Done()
}

// Consumer 代表 Kafka 消费者组
type UpdateValidationConsumer struct {
	ready chan bool // 定义一个通道，用于表示消费者组是否准备就绪
}

// Setup 在消费者组启动时调用
func (c *UpdateValidationConsumer) Setup(sarama.ConsumerGroupSession) error {
	close(c.ready) // 关闭通道以表示消费者组已准备就绪
	return nil
}

// Cleanup 在消费者组结束时调用
func (c *UpdateValidationConsumer) Cleanup(sarama.ConsumerGroupSession) error {
	return nil
}

// ConsumeClaim 消费消息
func (c *UpdateValidationConsumer) ConsumeClaim(session sarama.ConsumerGroupSession, claim sarama.ConsumerGroupClaim) error {
	fmt.Println("ConsumeClaim invoked...")
	log.Println("ConsumeClaim invoked...")

	// 处理消息
	for message := range claim.Messages() {
		// 处理消息
		err := processValidationResult(message, session)
		if err != nil {
			log.Printf("Error processing message: %v", err)
		}
	}

	return nil
}

// 处理验证结果并将其更新到 MongoDB 中
func processValidationResult(message *sarama.ConsumerMessage, session sarama.ConsumerGroupSession) error {
	// 解析消息
	result := string(message.Value)
	log.Printf("Received validation result: %s", result)

	// 解析结果并更新到 MongoDB 中
	err := crud.UpdateValidation(result, updateValidationCollection)
	if err != nil {
		return errors.New(fmt.Sprintf("error inserting document into MongoDB: %v", err))
	}

	session.MarkMessage(message, "")
	return nil
}
