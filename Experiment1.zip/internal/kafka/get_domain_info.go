package kafka

import (
	"context"
	"distributed/pkg/domain"
	"distributed/pkg/util"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"os/signal"
	"strconv"
	"sync"
	"syscall"

	"github.com/IBM/sarama"
)

var getterConsumer sarama.ConsumerGroup
var getterProducer sarama.AsyncProducer

func GetDomainInfo() {
	config := util.AppConfig

	// 连接到 Kafka broker
	kafkaConfig := sarama.NewConfig()
	kafkaConfig.Version = sarama.V2_8_1_0 // 使用 Kafka 2.8.1 版本

	kafkaClient, err := sarama.NewClient([]string{config.KafkaConfig.Broker.Host + ":" + strconv.Itoa(config.KafkaConfig.Broker.Port)}, kafkaConfig)
	if err != nil {
		log.Fatal(fmt.Sprintf("Error creating Kafka client: %v", err))
	}
	defer kafkaClient.Close()

	// 创建 Kafka 生产者
	getterProducer, err = sarama.NewAsyncProducerFromClient(kafkaClient)
	if err != nil {
		log.Fatalf("Error creating Kafka producer: %v", err)
	}
	defer getterProducer.Close()

	// 创建 Kafka 消费者组
	consumerGroup, err := sarama.NewConsumerGroupFromClient("task2_group1", kafkaClient)
	if err != nil {
		log.Fatal(fmt.Sprintf("Error creating Kafka consumer: %v", err))
	}
	// defer getterConsumer.Close()

	// 创建一个上下文以便取消操作
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// 监听操作系统的信号，以便在接收到中断信号时优雅地关闭程序
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-sigCh
		log.Println("Received termination signal. Shutting down...")
		fmt.Println("Received termination signal. Shutting down...")
		cancel()
	}()

	// 创建等待组
	var wg sync.WaitGroup

	// 启动100个消费者
	for i := 0; i < 2000; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			consumeDomain(ctx, id, consumerGroup, config)
		}(i)
	}

	wg.Wait()

	// 等待上下文被取消
	<-ctx.Done()
}

// 消费消息的函数
func consumeDomain(ctx context.Context, id int, consumerGroup sarama.ConsumerGroup, config util.Config) {
	// 创建消费者
	consumerInstance := GetterConsumer{
		id: id,
		// ready: make(chan bool),
	}

	// 启动 Kafka 消费者组
	for {
		// 检查上下文是否被取消，如果是，则退出循环
		if ctx.Err() != nil {
			log.Printf("In goroutine, ctx.Err(): %v\n", ctx.Err())
			fmt.Printf("In goroutine, ctx.Err(): %v\n", ctx.Err())
			return
		}

		fmt.Printf("Consumer %d: Consume will be invoked\n", id)
		err := consumerGroup.Consume(ctx, []string{config.TaskConfig.Task2.Topic1}, &consumerInstance)
		if err != nil {
			log.Printf("Error from consumer %d: %v", id, err)
		}

		// 等待消费者准备就绪
		// consumerInstance.ready = make(chan bool)
	}
}

// Consumer 代表 Kafka 消费者组
type GetterConsumer struct {
	id int
	// ready chan bool // 定义一个通道，用于表示消费者组是否准备就绪
}

// Setup 在消费者组启动时调用
func (c *GetterConsumer) Setup(sarama.ConsumerGroupSession) error {
	fmt.Printf("Consumer %d: Setup invoked\n", c.id)
	log.Printf("Consumer %d: Setup invoked\n", c.id)

	// close(c.ready) // 关闭通道以表示消费者组已准备就绪
	return nil
}

// Cleanup 在消费者组结束时调用
func (c *GetterConsumer) Cleanup(sarama.ConsumerGroupSession) error {
	fmt.Printf("Consumer %d: Cleanup invoked\n", c.id)
	log.Printf("Consumer %d: Cleanup invoked\n", c.id)

	return nil
}

// ConsumeClaim 消费消息
// session 是消费者组会话对象，claim 是从 Kafka 主题中获得的消费者组分配的消息
/*
   在 Kafka 的消费者组中，ConsumeClaim 方法是由消费者组进行调用的
   并且是在消费者准备好处理消息时自动调用的。

   具体来说，当消费者组从 Kafka Broker 订阅了一个或多个主题后，
   Kafka 会自动分配分区给消费者组中的每个消费者。
   然后，Kafka 会调用每个消费者的 ConsumeClaim 方法，并将分配给该消费者的分区中的消息传递给该方法进行处理。

   因此，ConsumeClaim 方法不需要手动调用，而是由 Kafka 的消费者组根据订阅的主题和消费者组的配置自动调用的。
*/
func (c *GetterConsumer) ConsumeClaim(session sarama.ConsumerGroupSession, claim sarama.ConsumerGroupClaim) error {
	log.Printf("ConsumeClaim invoked for partition: %d\n", claim.Partition())
	fmt.Printf("ConsumeClaim invoked for partition: %d\n", claim.Partition())

	// 处理消息
	for message := range claim.Messages() {
		// 处理消息
		err := getAndProduce(message, session)
		if err != nil {
			log.Printf("Error processing message: %v", err)
		}
	}

	return nil
}

func getAndProduce(msg *sarama.ConsumerMessage, session sarama.ConsumerGroupSession) error {
	// 解析消息中的域名
	domainName := string(msg.Value)

	// 获取域名信息
	domainInfo, err := domain.GetDomainInfo(domainName)
	if err != nil {
		// 如果获取域名信息失败
		log.Printf("Failed to get domain info for %s: %v", domainName, err)
		session.MarkMessage(msg, "")
		return err
	}

	// 将域名结构体编码为 JSON 格式
	domainInfoJSON, err := json.Marshal(domainInfo)
	if err != nil {
		// 如果编码为 JSON 失败
		log.Printf("Failed to encode domain info to JSON for %s: %v", domainName, err)
		session.MarkMessage(msg, "")
		return err
	}

	// 创建消息
	message := &sarama.ProducerMessage{
		Topic: util.AppConfig.TaskConfig.Task2.Topic2, // 发送到结果主题
		Value: sarama.ByteEncoder(domainInfoJSON),     // 将域名结构体编码为 JSON 格式的字节流
	}

	// 发送消息到 Kafka
	getterProducer.Input() <- message

	// 手动提交消息偏移量
	session.MarkMessage(msg, "")
	return nil
}
