package kafka

import (
	"context"
	"distributed/pkg/database"
	"distributed/pkg/util"
	"fmt"
	"hash/fnv"
	"log"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"github.com/IBM/sarama"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

func ProduceDomains(task string) {
	config := util.AppConfig

	// 连接到 Kafka broker
	kafkaConfig := sarama.NewConfig()
	kafkaConfig.Version = sarama.V2_8_1_0 // 使用 Kafka 2.8.1 版本

	kafkaClient, err := sarama.NewClient([]string{config.KafkaConfig.Broker.Host + ":" + strconv.Itoa(config.KafkaConfig.Broker.Port)}, kafkaConfig)
	if err != nil {
		log.Fatal(fmt.Sprintf("Error creating kafka client:  %v", err))
	}
	defer kafkaClient.Close()

	// 创建 Kafka 生产者
	kafkaProducer, err := sarama.NewAsyncProducerFromClient(kafkaClient)
	if err != nil {
		log.Fatal(fmt.Sprintf("Error creating kafka producer: %v", err))
	}
	defer kafkaProducer.Close()

	// 初始化 MongoDB 客户端
	mongoClient := database.GetClient()
	if mongoClient == nil {
		log.Fatal(fmt.Sprintf("Error connecting to MongoDB: %v", err))
	}
	//	defer mongoClient.Disconnect(context.Background())

	// 创建一个上下文以便取消操作
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// 监听操作系统的信号，以便在接收到中断信号时优雅地关闭程序
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-sigCh
		log.Printf("Received termination signal. Shutting down...")
		fmt.Printf("Received termination signal. Shutting down...")
		cancel()
	}()

	var task_config util.Task
	if task == "task1" {
		task_config = util.AppConfig.TaskConfig.Task1
	} else if task == "task2" {
		task_config = util.AppConfig.TaskConfig.Task2
	}

	produceDomains(ctx, kafkaProducer, mongoClient, task_config)

}

func produceDomains(ctx context.Context, kafkaProducer sarama.AsyncProducer, mongoClient *mongo.Client, task_config util.Task) {
	config := util.AppConfig.MongoConfig

	partition := 0 // 初始分区编号
	count := 0

	for {
		select {
		case <-ctx.Done():
			return
		default:
			// 初始化一个游标，用于遍历 MongoDB 中的记录
			// 	var cursor *mongo.Cursor
			// 	if task_config.Production == "tag.validation" {
			// 		cursor, err := mongoClient.Database(config.Database).Collection(config.Collection).Find(ctx, bson.M{task_config.Production: false})
			// 	if err != nil {
			// 		log.Printf(fmt.Sprintf("Error fetching records from MongoDB: %v", err))
			// 		return
			// 	}
			// }else if task_config.Production == "tag,info" {
			// 	cursor, err := mongoClient.Database(config.Database).Collection(config.Collection).Find(ctx, bson.M{task_config.Production: false, "tag.validation": true})
			// 	if err != nil {
			// 		log.Printf(fmt.Sprintf("Error fetching records from MongoDB: %v", err))
			// 		return
			// 	}
			// }else{
			// 	log.Println("Invalid production.")
			// 	return
			// }

			cursor, err := mongoClient.Database(config.Database).Collection(config.Collection).Find(ctx, bson.M{task_config.Production: false})
			if err != nil {
				log.Printf(fmt.Sprintf("Error fetching records from MongoDB: %v", err))
				return
			}

			defer cursor.Close(ctx)

			// 从 MongoDB 中获取一批域名
			domains, err := getBatchDomains(ctx, cursor, task_config.Batchsize1)
			if err != nil {
				log.Printf(fmt.Sprintf("Error fetching domains from database: %v", err))
				continue
			}

			// 如果获取的域名为空，则表示游标遍历结束，退出循环
			if len(domains) == 0 {
				log.Println("All records fetched, exiting produceDomains loop")
				return
			}

			// 将域名分发到 Kafka 的分区中
			for _, domain := range domains {
				// partition := hashString(domain) % task_config.Partition1 // 使用域名的哈希值来选择分区
				//				log.Printf("Partition: %v\n", partition)

				// 创建消息
				message := &sarama.ProducerMessage{
					Topic:     task_config.Topic1,
					Partition: int32(partition), // 将选择的分区赋值给消息的分区属性
					Key:       nil,
					Value:     sarama.StringEncoder(domain),
				}
				// 发送消息到 Kafka
				kafkaProducer.Input() <- message

				// 标记已访问
				_, err := mongoClient.Database(config.Database).Collection(config.Collection).UpdateOne(ctx, bson.M{"domain_name": domain}, bson.M{"$set": bson.M{task_config.Production: true}})
				if err != nil {
					log.Printf(fmt.Sprintf("Error updating tag for domain %s: %v", domain, err))
					continue
				}

				// 递增分区编号
				partition++
				// 如果分区编号超过最大分区数，则重置为0
				if partition >= task_config.Partition1 {
					partition = 0
				}
			}

			count += len(domains)

			if count%(10*task_config.Batchsize1) == 0 {
				log.Println(fmt.Sprintf("Produced %d domains to Kafka totally", count))
				fmt.Println(fmt.Sprintf("Produced %d domains to Kafka totally", count))
			}

			// 等待一段时间再次生产域名
			time.Sleep(30 * time.Second)
		}
	}
}

func getBatchDomains(ctx context.Context, cursor *mongo.Cursor, batchSize int) ([]string, error) {
	log.Printf("Begin getting a batch domains...")
	var domains []string

	// 从游标中获取一批域名
	for i := 0; i < batchSize && cursor.Next(ctx); i++ {
		var result bson.M
		if err := cursor.Decode(&result); err != nil {
			log.Printf(fmt.Sprintf("Error decoding record: %v", err))
			continue
		}
		name, ok := result["domain_name"].(string)
		if !ok {
			log.Printf("Invalid domain name format")
			continue
		}
		// log.Printf(name)
		domains = append(domains, name)
	}

	if err := cursor.Err(); err != nil {
		log.Printf(fmt.Sprintf("Cursor error: %v", err))
	}

	// log.Printf(domains)
	log.Printf("End the batch.")
	return domains, nil
}

func hashString(s string) int {
	h := fnv.New32a()
	h.Write([]byte(s))
	return int(h.Sum32())
}
