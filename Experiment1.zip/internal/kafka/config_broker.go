package kafka

import (
	"distributed/pkg/util"
	"log"
	"strconv"
	"time"

	"github.com/IBM/sarama"
)

func ConfigBroker() {
	config := util.AppConfig

	// 连接到 Kafka broker
	kafkaConfig := sarama.NewConfig()
	kafkaConfig.Version = sarama.V2_8_1_0 // 使用 Kafka 2.8.1 版本

	admin, err := sarama.NewClusterAdmin([]string{config.KafkaConfig.Broker.Host + ":" + strconv.Itoa(config.KafkaConfig.Broker.Port)}, kafkaConfig)
	if err != nil {
		log.Fatalf("Error connecting to Kafka broker: %v", err)
	}
	defer admin.Close()

	// 删除主题的所有分区及备份
	for _, topicConfig := range config.KafkaConfig.Topics {

		// 尝试删除主题
		err = admin.DeleteTopic(topicConfig.Name)
		if err != nil && err != sarama.ErrUnknownTopicOrPartition {
			log.Fatalf("Error deleting topic '%s': %v", topicConfig.Name, err)
		} else {
			log.Printf("Topic '%s' deleted successfully", topicConfig.Name)
		}
		// 等待主题被删除
		for {
			// 等待一段时间后再次检查
			time.Sleep(1 * time.Second)

			exists, err := topicExists(admin, topicConfig.Name)
			if err != nil {
				log.Fatalf("Error checking topic '%s' existence: %v", topicConfig.Name, err)
			}

			// 如果主题不存在，则退出循环
			if !exists {
				break
			}
		}

		// 创建主题及其分区
		err = createTopic(admin, topicConfig.Name, int32(topicConfig.Partitions))
		if err != nil {
			log.Printf("Error creating topic '%s': %v", topicConfig.Name, err)
			continue
		}
		log.Printf("Topic '%s' created successfully\n", topicConfig.Name)
	}
}

func createTopic(admin sarama.ClusterAdmin, topic string, numPartitions int32) error {
	topicDetail := &sarama.TopicDetail{
		NumPartitions:     numPartitions,
		ReplicationFactor: 1,
	}
	return admin.CreateTopic(topic, topicDetail, false)
}

// 检查主题是否存在
func topicExists(admin sarama.ClusterAdmin, topic string) (bool, error) {
	topics, err := admin.ListTopics()
	if err != nil {
		return false, err
	}

	_, exists := topics[topic]
	return exists, nil
}

func DeleteCOnsumerOffset() {
	config := util.AppConfig

	// 连接到 Kafka broker
	kafkaConfig := sarama.NewConfig()
	kafkaConfig.Version = sarama.V2_8_1_0 // 使用 Kafka 2.8.1 版本

	admin, err := sarama.NewClusterAdmin([]string{config.KafkaConfig.Broker.Host + ":" + strconv.Itoa(config.KafkaConfig.Broker.Port)}, kafkaConfig)
	if err != nil {
		log.Fatalf("Error connecting to Kafka broker: %v", err)
	}
	defer admin.Close()

	// 尝试删除主题
	err = admin.DeleteTopic("__consumer_offsets")
	if err != nil && err != sarama.ErrUnknownTopicOrPartition {
		log.Fatalf("Error deleting topic __consumer_offsets: %v", err)
	} else {
		log.Printf("Topic __consumer_offsets deleted successfully\n")
	}

}

func DeleteAllTopic() {
	config := util.AppConfig

	// 连接到 Kafka broker
	kafkaConfig := sarama.NewConfig()
	kafkaConfig.Version = sarama.V2_8_1_0 // 使用 Kafka 2.8.1 版本

	admin, err := sarama.NewClusterAdmin([]string{config.KafkaConfig.Broker.Host + ":" + strconv.Itoa(config.KafkaConfig.Broker.Port)}, kafkaConfig)
	if err != nil {
		log.Fatalf("Error connecting to Kafka broker: %v", err)
	}
	defer admin.Close()

	// 删除主题的所有分区及备份
	for _, topicConfig := range config.KafkaConfig.Topics {

		// 尝试删除主题
		err = admin.DeleteTopic(topicConfig.Name)
		if err != nil && err != sarama.ErrUnknownTopicOrPartition {
			log.Fatalf("Error deleting topic '%s': %v", topicConfig.Name, err)
		} else {
			log.Printf("Topic '%s' deleted successfully", topicConfig.Name)
		}
	}
}
