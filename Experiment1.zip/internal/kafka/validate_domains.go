package kafka

import (
	"context"
	"distributed/pkg/domain"
	"distributed/pkg/util"
	"fmt"
	"log"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	// "time"
	"sync"

	"github.com/IBM/sarama"
)

var validationConsumer sarama.ConsumerGroup
var validationProducer sarama.AsyncProducer

// ValidateDomains 从主题“域名待验证”中读取域名并验证，然后写入新的主题“合法性更新”
func ValidateDomains() {
	config := util.AppConfig

	// 连接到 Kafka broker
	kafkaConfig := sarama.NewConfig()
	kafkaConfig.Version = sarama.V2_8_1_0 // 使用 Kafka 2.8.1 版本
	kafkaConfig.Consumer.Return.Errors = true

	kafkaClient, err := sarama.NewClient([]string{config.KafkaConfig.Broker.Host + ":" + strconv.Itoa(config.KafkaConfig.Broker.Port)}, kafkaConfig)
	if err != nil {
		log.Fatal(fmt.Sprintf("Error creating Kafka client: %v", err))
	}
	defer kafkaClient.Close()

	// 创建 Kafka 生产者
	validationProducer, err = sarama.NewAsyncProducerFromClient(kafkaClient)
	if err != nil {
		log.Fatalf("Error creating Kafka producer: %v", err)
	}
	defer validationProducer.Close()

	// 创建 Kafka 消费者组
	consumerGroup, err := sarama.NewConsumerGroupFromClient("task1_group1", kafkaClient)
	if err != nil {
		log.Fatal(fmt.Sprintf("Error creating Kafka consumer: %v", err))
		return
	}

	go func() {
		for err := range consumerGroup.Errors() {
			log.Printf("Group errors: %v", err)
		}
	}()

	// defer validationConsumer.Close()

	// 创建一个上下文以便取消操作
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// 监听操作系统的信号，以便在接收到中断信号时优雅地关闭程序
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	go func() {
		<-sigCh
		log.Println("Received termination signal. Shutting down...")
		fmt.Println("Received termination signal. Shutting down...")
		cancel()
	}()

	// // 消费者
	// consumer := ValidationConsumer{
	// 	ready: make(chan bool),
	// }

	// 创建等待组
	var wg sync.WaitGroup

	// 启动100个消费者
	for i := 0; i < 2000; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			consumeMessages(ctx, id, consumerGroup, config)
		}(i)
	}

	wg.Wait()

	// 启动 Kafka 消费者组
	// go func() {
	// 	for {
	// 		// 检查上下文是否被取消，如果是，则退出循环
	// 		if ctx.Err() != nil {
	// 			log.Printf("In goroutine, ctx.Err(): %v", ctx.Err())
	// 			fmt.Printf("In goroutine, ctx.Err(): %v", ctx.Err())
	// 			return
	// 		}

	// 		fmt.Println("Consume will be invoked")
	// 		err := validationConsumer.Consume(ctx, []string{config.TaskConfig.Task1.Topic1}, &consumer)
	// 		if err != nil {
	// 			log.Printf("Error from consumer: %v", err)
	// 		}

	// 		consumer.ready = make(chan bool)
	// 	}
	// }()

	// <-consumer.ready // 等待消费者组准备好

	// log.Println("Consumer group is ready, consuming messages...")
	// fmt.Println("Consumer group is ready, consuming messages...")

	// 等待上下文被取消
	<-ctx.Done()
}

// 消费消息的函数
func consumeMessages(ctx context.Context, id int, consumerGroup sarama.ConsumerGroup, config util.Config) {
	// 创建消费者
	consumerInstance := ValidationConsumer{
		id: id,
		// ready: make(chan bool),
	}

	// 启动 Kafka 消费者组
	for {
		// 检查上下文是否被取消，如果是，则退出循环
		if ctx.Err() != nil {
			log.Printf("In goroutine, ctx.Err(): %v\n", ctx.Err())
			fmt.Printf("In goroutine, ctx.Err(): %v\n", ctx.Err())
			return
		}

		fmt.Printf("Consumer %d: Consume will be invoked\n", id)
		err := consumerGroup.Consume(ctx, []string{config.TaskConfig.Task1.Topic1}, &consumerInstance)
		if err != nil {
			log.Printf("Error from consumer %d: %v", id, err)
		}

		// 等待消费者准备就绪
		// consumerInstance.ready = make(chan bool)
	}
}

// 代表 Kafka 消费者
type ValidationConsumer struct {
	id int // 消费者的标识符
	// ready chan bool // 定义一个通道，用于表示消费者组是否准备就绪
}

// Setup 在消费者启动时调用
func (c *ValidationConsumer) Setup(sarama.ConsumerGroupSession) error {
	fmt.Printf("Consumer %d: Setup invoked\n", c.id)
	log.Printf("Consumer %d: Setup invoked\n", c.id)

	// time.Sleep(3 * time.Second)

	// close(c.ready) // 关闭通道以表示消费者组已准备就绪
	return nil
}

// Cleanup 在消费者结束时调用
func (c *ValidationConsumer) Cleanup(sarama.ConsumerGroupSession) error {
	fmt.Printf("Consumer %d: Cleanup invoked\n", c.id)
	log.Printf("Consumer %d: Cleanup invoked\n", c.id)

	return nil
}

// ConsumeClaim 消费消息
// session 是消费者组会话对象，claim 是从 Kafka 主题中获得的消费者组分配的消息
/*
   在 Kafka 的消费者组中，ConsumeClaim 方法是由消费者组进行调用的
   并且是在消费者准备好处理消息时自动调用的。

   具体来说，当消费者组从 Kafka Broker 订阅了一个或多个主题后，
   Kafka 会自动分配分区给消费者组中的每个消费者。
   然后，Kafka 会调用每个消费者的 ConsumeClaim 方法，并将分配给该消费者的分区中的消息传递给该方法进行处理。

   因此，ConsumeClaim 方法不需要手动调用，而是由 Kafka 的消费者组根据订阅的主题和消费者组的配置自动调用的。
*/
func (c *ValidationConsumer) ConsumeClaim(session sarama.ConsumerGroupSession, claim sarama.ConsumerGroupClaim) error {
	log.Printf("ConsumeClaim invoked for partition: %d\n", claim.Partition())
	fmt.Printf("ConsumeClaim invoked for partition: %d\n", claim.Partition())

	// count := 0
	// 处理消息
	for message := range claim.Messages() {
		// 处理消息
		err := validateAndProduce(message, session)
		if err != nil {
			log.Printf("Error processing message: %v", err)
		}

		// count += 1

		// if count % 1000 == 0 {
		// 	fmt.Printf("Current count: %d\n", count)
		// }
	}

	// fmt.Printf("Processed %d messages for partition: %d\n", count, claim.Partition())

	return nil
}

// 验证域名并将结果写入新主题
func validateAndProduce(msg *sarama.ConsumerMessage, session sarama.ConsumerGroupSession) error {
	// 解析消息中的域名
	domainName := string(msg.Value)

	validationResult := domain.IsDomainValid(domainName)

	// 创建消息
	message := &sarama.ProducerMessage{
		Topic: util.AppConfig.TaskConfig.Task1.Topic2, // 发送到结果主题
		Value: sarama.StringEncoder(fmt.Sprintf("Domain: %s, Success: %t, StatusCode: %d, RedirectLocation: %s",
			domainName, validationResult.Success, validationResult.StatusCode, validationResult.RedirectLocation)), // 将域名和验证结果编码为字符串
	}

	// 发送消息到 Kafka
	validationProducer.Input() <- message

	// 手动提交消息偏移量
	session.MarkMessage(msg, "")
	return nil
}
