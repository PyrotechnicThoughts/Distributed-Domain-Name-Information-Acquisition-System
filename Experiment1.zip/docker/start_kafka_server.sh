#!/bin/bash

# 检查是否存在名为 "kafka" 的容器
if [ "$(docker ps -aq -f name=kafka_server)" ]; then
    # 如果存在，则先停止它
    docker stop kafka_server
fi

# 启动 Kafka 容器
docker start kafka_server || docker run -d --name kafka_server --network distributed --network-alias kafka_server -p 9092:9092 --env KAFKA_LISTENERS=PLAINTEXT://0.0.0.0:9092 --env KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://127.0.0.1:9092 --env KAFKA_LISTENER_SECURITY_PROTOCOL_MAP=PLAINTEXT:PLAINTEXT --env KAFKA_INTER_BROKER_LISTENER_NAME=PLAINTEXT --env KAFKA_ZOOKEEPER_CONNECT=zookeeper:2181 wurstmeister/kafka

