#!/bin/bash

# 检查是否存在名为 "zookeeper" 的容器
if [ "$(docker ps -aq -f name=zookeeper)" ]; then
    # 如果存在，则先停止它
    docker stop zookeeper
fi

# 启动 ZooKeeper 容器
docker start zookeeper || docker run -d --name zookeeper --network distributed --network-alias zookeeper -p 2181:2181 wurstmeister/zookeeper

